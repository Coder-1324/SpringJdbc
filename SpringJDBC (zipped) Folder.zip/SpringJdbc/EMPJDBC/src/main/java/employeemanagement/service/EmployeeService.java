package employeemanagement.service;
import java.util.List;
import employeemanagement.model.Employee;



public interface EmployeeService {
	    void addEmployee(Employee employee);
	    void updateEmployee(Employee employee);
	    void deleteEmployee(int id);
	    Employee getEmployeeById(int id);
	    List<Employee> getAllEmployees();
	}

