package spring.EMPjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context =
       		 new ClassPathXmlApplicationContext("spring/EMPjdbc/config.xml");
       JdbcTemplate template =context.getBean("jdbcTamplate",JdbcTemplate.class);
       
       //insert query
       
       String query ="insert into student(id,name,city) values(?,?)";
       
       ///fire the query
       
       int result = template.update(query,101,"ram");
       System.out.println("number of record inserted"+result);
    }
}
